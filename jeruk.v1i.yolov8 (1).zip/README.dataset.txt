# jeruk > 2025-04-09 6:52pm
https://universe.roboflow.com/tumbil/jeruk-ctagc

Provided by a Roboflow user
License: Public Domain

